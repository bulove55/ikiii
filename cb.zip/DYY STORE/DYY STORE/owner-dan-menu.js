const fs = require('fs')

global.namabot = "DyyServer"
global.namaowner = "Aldy"
global.footer_text = "©" + namabot
global.pp_bot = fs.readFileSync("./image/foto.jpg")
global.qris = fs.readFileSync("./image/qris.jpg")
global.owner = ['6285891690670']
global.sessionName = 'session'
global.prefa = ['-_-']
global.caption_pay = `Berikut List Payment Kami

Ovo ➪ 085891690670
Dana ➪ 085891690670
Gopay ➪ 085891690670

© DyyStore ➪ Pembayaran
`
module.exports.helpMenu = (pushname) =>{
  return `Halo ${pushname} Im,DyyBot Berikut List Yang Saya Punya!

*「 DYY - STORE 」*

\`\`\`• !owner
• !pay (bayar)
• !list (list produk)

「 ADMIN - MENU 」

• !addlist (add produk)
• !updatelist (edit produk)
• !dellist (delete produk)
• !jeda 
• !tambah (+)
• !kurang (-)
• !kali (×)
• !bagi (:)
• !setproses (edit proses)
• !changeproses (ubah proses)
• !delsetproses (hapus proses)
• !setdone (edit selesai)
• !changedone (ubah selesai)
• !delsetdone (hapus selesai)
• !proses (loading)
• !done (selesai)
• !welcome (on/off)
• !goodbye (on/off)
• !setwelcome (edit welcome)
• !changewelcome (ubah welcome)
• !delsetwelcome (hapus welcome)
• !setleft (edit keluar)
• !changeleft (ubah keluar)
• !delsetleft (hapus keluar)
• !antiwame (on/off)
• !antilink (on/off)
• !open (buka group)
• !close (tutup group)
• !hidetag (pengumuman)
\`\`\`

📝 *NOTE*: 
Fitur nya bisa dipakai dengan atau
tanpa prefix (simbol awalan). Sebagai contoh 
fitur .owner (prefix)
dan bisa juga owner (tanpa prefix)
`
}